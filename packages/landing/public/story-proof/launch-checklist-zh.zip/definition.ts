export const definition = {
  "id": "launch-checklist",
  "title": "上线清单",
  "items": [
    {
      "group": "上线前",
      "task": "核对发行说明",
      "doneWhen": ""
    },
    {
      "group": "上线前",
      "task": "在新环境试装",
      "doneWhen": ""
    },
    {
      "group": "上线前",
      "task": "发布已签名的构建",
      "doneWhen": ""
    }
  ]
}
;