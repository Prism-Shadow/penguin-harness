export const definition = {
  "id": "launch-checklist",
  "title": "Launch checklist",
  "items": [
    {
      "group": "Before release",
      "task": "Review the release notes",
      "doneWhen": ""
    },
    {
      "group": "Before release",
      "task": "Try the install on a clean machine",
      "doneWhen": ""
    },
    {
      "group": "Before release",
      "task": "Publish the signed build",
      "doneWhen": ""
    }
  ]
}
;